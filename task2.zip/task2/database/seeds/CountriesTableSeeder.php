<?php

use Illuminate\Database\Seeder;

class CountriesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()

    {
    	DB::table('countries')->delete();
          DB::table('countries')->insert([

                [
                    'name' => 'Australia',
                    'iso2' => 'AU',
                    'iso3' => 'AUS'

                ],
                [
                    'name' => 'Bangladesh',
                    'iso2' => 'BD',
                    'iso3' => 'BGD'
                ],
                [
                    'name' => 'China',
                    'iso2' => 'CN',
                    'iso3' => 'CHN'
                ],
                [
                    'name' => 'Denmark',
                    'iso2' => 'DK',
                    'iso3' => 'DNK'
                ],
                 [
                    'name' => 'Egypt',
                    'iso2' => 'EG',
                    'iso3' => 'EGY'
                ],
                [
                    'name' => 'France',
                    'iso2' => 'FR',
                    'iso3' => 'FRA'
                ],
                [
                    'name' => 'Germany',
                    'iso2' => 'DE',
                    'iso3' => 'DEU'
                ],
                [
                    'name' => 'India',
                    'iso2' => 'IN',
                    'iso3' => 'IND'
                ],
                [
                	'name'=>'United States of America',
                	'iso2'=>'US',
                	'iso3'=>'USA'
                ],
                [
                    'name' => 'New Zealand',
                    'iso2' => 'NZ',
                    'iso3' => 'NZL'
                ]
          
        ]);
    }
}
