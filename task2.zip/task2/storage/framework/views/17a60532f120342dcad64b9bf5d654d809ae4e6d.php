<!DOCTYPE html>
<html lang="en">
<head>
	<title>Countries</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="<?php echo e(url('css/bootstrap.min.css')); ?>">

</head>
<body>

	<div class="container">
		
		<h2 align="center">Countries With ISO code</h2>
		<div class="row">
			<div class="col-md-1"><h4>Filter </h4> </div>
			<form id="filter-form" action="<?php echo e(url('filter')); ?>" method="get">
				<div class="col-md-3">
					<select class="form-control" id="iso2" name="iso2" >
						<option value='all'> Select code</option>
						<?php $__currentLoopData = $country_code; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $retrive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<option <?php echo e($iso2 ==$retrive->iso2 ? "selected" :''); ?> value="<?php echo e($retrive->iso2); ?>"><?php echo e($retrive->name .' ('.$retrive->iso2.') '); ?></option>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>

				</div>
			</form>
		</div>
		<?php if(empty(json_decode($countries_data))): ?>

		<h4 align="center">No data found</h4>
		<?php else: ?> 

		<table class="table">
			<thead>
				<tr>
					<th>Name</th>
					<th>ISO2</th>
					<th>ISO3</th>
					
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = json_decode($countries_data); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $retrive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($retrive->name); ?></td>
					<td><?php echo e($retrive->iso2); ?></td>
					<td><?php echo e($retrive->iso3); ?></td>
					
				</tr>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



			</tbody>
		</table>
		<?php endif; ?>
	</div>

</body>
</html>
<script>
document.getElementById("iso2").addEventListener("change",function(){
document.getElementById('filter-form').submit();
})
</script>