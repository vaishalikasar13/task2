<!DOCTYPE html>
<html lang="en">
<head>
	<title>Countries</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="{{url('css/bootstrap.min.css')}}">

</head>
<body>

	<div class="container">
		
		<h2 align="center">Countries With ISO code</h2>
		<div class="row">
			<div class="col-md-1"><h4>Filter </h4> </div>
			<form id="filter-form" action="{{url('filter')}}" method="get">
				<div class="col-md-3">
					<select class="form-control" id="iso2" name="iso2" >
						<option value='all'> Select code</option>
						@foreach ($country_code as $retrive)

						<option {{ $iso2 ==$retrive->iso2 ? "selected" :''}} value="{{ $retrive->iso2 }}">{{  $retrive->name .' ('.$retrive->iso2.') ' }}</option>

						@endforeach
					</select>

				</div>
			</form>
		</div>
		@if(empty(json_decode($countries_data)))

		<h4 align="center">No data found</h4>
		@else 

		<table class="table">
			<thead>
				<tr>
					<th>Name</th>
					<th>ISO2</th>
					<th>ISO3</th>
					
				</tr>
			</thead>
			<tbody>
				@foreach (json_decode($countries_data) as $retrive)
				<tr>
					<td>{{ $retrive->name }}</td>
					<td>{{ $retrive->iso2 }}</td>
					<td>{{ $retrive->iso3 }}</td>
					
				</tr>

				@endforeach



			</tbody>
		</table>
		@endif
	</div>

</body>
</html>
<script>
document.getElementById("iso2").addEventListener("change",function(){
document.getElementById('filter-form').submit();
})
</script>